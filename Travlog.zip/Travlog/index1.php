<?php
$var=4;
$var3=6;
$var2="hello";
echo  $var+$var3." ".$var2."\t";

echo $var2." ".$var3+$var;


?>