<?php

$host = "localhost";
$username="test1";
$password="test1";
$db_name="test";

$con = mysqli_connect($host,$username,$password,$db_name);

?>